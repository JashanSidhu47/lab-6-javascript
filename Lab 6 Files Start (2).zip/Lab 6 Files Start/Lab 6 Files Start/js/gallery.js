// script.js
// STEP 1: Initialize and declare variables
var displayedImage = document.querySelector('.displayed-img');
var thumbBar = document.querySelector('.thumb-bar');

/* STEP 2: Loop 5 times to create the <img> elements */
for (var i = 1; i < 6; i++) {
  var newImage = document.createElement('img');
  newImage.setAttribute('src', 'images/pic' + i + '.jpg');
  thumbBar.appendChild(newImage);
}

/* STEP 4: Function to change the src of the main <img> */
function displayImage(value) {
  displayedImage.setAttribute('src', value);
}

/* STEP 5: Event Delegation */
thumbBar.onclick = function (event) {
  // event.target is the element that was clicked
  if (event.target && event.target.nodeName === 'IMG') {
    var imgSrc = event.target.getAttribute('src');
    displayImage(imgSrc);

    // Lab 6 STEP A: Change the event.target CSS outline property to "5px solid red"
    // Lab 6 STEP B: Change the event.target CSS position property to "relative"
    // Lab 6 STEP C: Set the CSS z-index property to "10" so that the thumbnail clicked is on top of all the others

    // Call the clearWayfinding() function
    clearWayfinding(event.target);
  }
};

// Lab 6 STEP D: Initialize and declare a var called 'thumbImgs' using the querySelectorAll method to grab all the IMG elements inside the .thumb-bar
var thumbImgs = document.querySelectorAll('.thumb-bar img');

// Lab 6 STEP E: Build a function called 'clearWayfinding()' that loops through the thumbImgs array with a FOR loop
function clearWayfinding(clickedImg) {
  for (var i = 0; i < thumbImgs.length; i++) {
    // Lab 6 STEP F: Inside the clearWayfinding function, for each thumbImgs IMG element, set the CSS outline-width property to "0", and the z-index property also to "0"
    thumbImgs[i].style.outlineWidth = '0';
    thumbImgs[i].style.zIndex = '0';
  }

  // Lab 6 STEP G: Inside the clearWayfinding function, set the CSS outline-width property to "5px solid red", and the z-index property to "10" for the clickedImg
  clickedImg.style.outlineWidth = '5px';
  clickedImg.style.zIndex = '10';
}
